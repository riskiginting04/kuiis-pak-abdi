package com.example.quiz_pemrograman.activities

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.quiz_pemrograman.R
import com.example.quiz_pemrograman.model.Movie

class DetailMovieActivity : AppCompatActivity() {

    private lateinit var imgPoster: ImageView
    private lateinit var tvJudul: TextView
    private lateinit var tvGenre: TextView
    private lateinit var tvRating: TextView
    private lateinit var tvDeskripsi: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportActionBar?.hide()

        setContentView(R.layout.activity_detail_movie)

        imgPoster = findViewById(R.id.imgPosterDetail)
        tvJudul = findViewById(R.id.tvDetailJudul)
        tvGenre = findViewById(R.id.tvDetailGenre)
        tvRating = findViewById(R.id.tvDetailRating)
        tvDeskripsi = findViewById(R.id.tvDetailDeskripsi)

        val movie = intent.getSerializableExtra("movie") as? Movie

        if (movie != null) {

            tvJudul.text = movie.judul
            tvGenre.text = movie.genre
            tvRating.text = "⭐ ${movie.rating}"
            tvDeskripsi.text = movie.deskripsi

            if (movie.poster.isNotEmpty()) {

                Glide.with(this)
                    .load(movie.poster)
                    .placeholder(R.mipmap.ic_launcher)
                    .error(R.mipmap.ic_launcher)
                    .into(imgPoster)

            } else {

                imgPoster.setImageResource(R.mipmap.ic_launcher)

            }

        }

    }

}