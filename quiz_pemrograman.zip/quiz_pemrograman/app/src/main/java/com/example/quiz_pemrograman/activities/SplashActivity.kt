package com.example.quiz_pemrograman.activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.quiz_pemrograman.R

class SplashActivity : AppCompatActivity() {

    private lateinit var txtApp: TextView
    private lateinit var txtLoading: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportActionBar?.hide()

        setContentView(R.layout.activity_splash)

        txtApp = findViewById(R.id.txtApp)
        txtLoading = findViewById(R.id.txtLoading)

        val zoomAnimation = AnimationUtils.loadAnimation(
            this,
            R.anim.zoom_fade_in
        )

        val blinkAnimation = AnimationUtils.loadAnimation(
            this,
            R.anim.blink
        )

        txtApp.startAnimation(zoomAnimation)
        txtLoading.startAnimation(blinkAnimation)

        Handler(Looper.getMainLooper()).postDelayed({

            startActivity(
                Intent(
                    this,
                    LoginActivity::class.java
                )
            )

            finish()

        }, 3000)

    }
}