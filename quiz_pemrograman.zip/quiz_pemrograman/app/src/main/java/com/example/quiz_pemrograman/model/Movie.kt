package com.example.quiz_pemrograman.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class Movie(

    @SerializedName("id")
    val id: Int,

    @SerializedName("judul")
    val judul: String,

    @SerializedName("genre")
    val genre: String,

    @SerializedName("rating")
    val rating: String,

    @SerializedName("deskripsi")
    val deskripsi: String,

    @SerializedName("poster")
    val poster: String

) : Serializable