package com.example.quiz_pemrograman.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class User(

    @SerializedName("id")
    val id: Int,

    @SerializedName("nama")
    val nama: String,

    @SerializedName("email")
    val email: String,

    @SerializedName("password")
    val password: String? = null,

    @SerializedName("foto")
    val foto: String? = "",

    @SerializedName("no_hp")
    val noHp: String? = ""

) : Serializable