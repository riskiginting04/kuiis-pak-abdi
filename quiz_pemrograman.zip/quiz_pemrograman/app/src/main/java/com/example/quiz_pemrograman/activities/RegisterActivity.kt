package com.example.quiz_pemrograman.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.quiz_pemrograman.R
import com.example.quiz_pemrograman.api.ApiClient
import com.example.quiz_pemrograman.model.RegisterResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegisterActivity : AppCompatActivity() {

    private lateinit var etNama: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText

    private lateinit var btnRegister: Button
    private lateinit var tvLogin: TextView
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportActionBar?.hide()

        setContentView(R.layout.activity_register)

        etNama = findViewById(R.id.etNama)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)

        btnRegister = findViewById(R.id.btnRegister)
        tvLogin = findViewById(R.id.tvLogin)
        progressBar = findViewById(R.id.progressBar)

        btnRegister.setOnClickListener {

            register()

        }

        tvLogin.setOnClickListener {

            finish()

        }

    }

    private fun register() {

        val nama = etNama.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString().trim()

        if (nama.isEmpty()) {

            etNama.error = "Nama tidak boleh kosong"
            etNama.requestFocus()
            return

        }

        if (email.isEmpty()) {

            etEmail.error = "Email tidak boleh kosong"
            etEmail.requestFocus()
            return

        }

        if (password.length < 6) {

            etPassword.error = "Password minimal 6 karakter"
            etPassword.requestFocus()
            return

        }

        progressBar.visibility = View.VISIBLE
        btnRegister.isEnabled = false

        ApiClient.instance.register(
            nama,
            email,
            password
        ).enqueue(object : Callback<RegisterResponse> {

            override fun onResponse(
                call: Call<RegisterResponse>,
                response: Response<RegisterResponse>
            ) {

                progressBar.visibility = View.GONE
                btnRegister.isEnabled = true

                if (response.isSuccessful &&
                    response.body() != null &&
                    response.body()!!.success
                ) {

                    Toast.makeText(
                        this@RegisterActivity,
                        "Registrasi berhasil",
                        Toast.LENGTH_SHORT
                    ).show()

                    startActivity(
                        Intent(
                            this@RegisterActivity,
                            LoginActivity::class.java
                        )
                    )

                    finish()

                } else {

                    Toast.makeText(
                        this@RegisterActivity,
                        response.body()?.message ?: "Registrasi gagal",
                        Toast.LENGTH_SHORT
                    ).show()

                }

            }

            override fun onFailure(
                call: Call<RegisterResponse>,
                t: Throwable
            ) {

                progressBar.visibility = View.GONE
                btnRegister.isEnabled = true

                Toast.makeText(
                    this@RegisterActivity,
                    "Error : ${t.message}",
                    Toast.LENGTH_LONG
                ).show()

            }

        })

    }

}