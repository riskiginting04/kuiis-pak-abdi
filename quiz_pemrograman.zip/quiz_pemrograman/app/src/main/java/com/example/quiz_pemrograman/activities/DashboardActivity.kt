package com.example.quiz_pemrograman.activities

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.quiz_pemrograman.R
import com.example.quiz_pemrograman.adapter.MovieAdapter
import com.example.quiz_pemrograman.api.ApiClient
import com.example.quiz_pemrograman.model.Movie
import com.example.quiz_pemrograman.model.MovieResponse
import com.example.quiz_pemrograman.session.SessionManager
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DashboardActivity : AppCompatActivity(),
    MovieAdapter.OnMovieClickListener {

    private lateinit var tvNama: TextView
    private lateinit var tvEmail: TextView
    private lateinit var btnLogout: ImageButton
    private lateinit var btnProfile: ImageButton
    private lateinit var recyclerMovie: RecyclerView
    private lateinit var searchMovie: SearchView

    private lateinit var session: SessionManager
    private lateinit var adapter: MovieAdapter

    private val movieList = ArrayList<Movie>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_dashboard)

        session = SessionManager(this)

        tvNama = findViewById(R.id.tvNama)
        tvEmail = findViewById(R.id.tvEmail)
        btnLogout = findViewById(R.id.btnLogout)
        btnProfile = findViewById(R.id.btnProfile)
        recyclerMovie = findViewById(R.id.recyclerMovie)
        searchMovie = findViewById(R.id.searchMovie)

        tvNama.text = session.getNama()
        tvEmail.text = session.getEmail()

        adapter = MovieAdapter(movieList, this)
        recyclerMovie.layoutManager = LinearLayoutManager(this)
        recyclerMovie.adapter = adapter

        getMovies()

        btnProfile.setOnClickListener {
            startActivity(
                Intent(this, ProfileActivity::class.java)
            )
        }

        btnLogout.setOnClickListener {
            session.logout()

            val intent = Intent(
                this,
                LoginActivity::class.java
            ).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TASK
            }

            startActivity(intent)
            finish()
        }

        searchMovie.setOnQueryTextListener(
            object : SearchView.OnQueryTextListener {

                override fun onQueryTextSubmit(query: String?): Boolean {
                    if (!query.isNullOrEmpty()) {
                        searchMovies(query)
                    }
                    return true
                }

                override fun onQueryTextChange(newText: String?): Boolean {
                    if (newText.isNullOrEmpty()) {
                        getMovies()
                    } else {
                        searchMovies(newText)
                    }
                    return true
                }
            }
        )
    }

    private fun getMovies() {
        ApiClient.instance.getMovies()
            .enqueue(object : Callback<MovieResponse> {

                override fun onResponse(
                    call: Call<MovieResponse>,
                    response: Response<MovieResponse>
                ) {
                    val result = response.body()

                    if (response.isSuccessful &&
                        result != null &&
                        result.success
                    ) {
                        movieList.clear()
                        movieList.addAll(result.data)
                        adapter.notifyDataSetChanged()
                    } else {
                        Toast.makeText(
                            this@DashboardActivity,
                            "Data movie tidak ditemukan",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onFailure(
                    call: Call<MovieResponse>,
                    t: Throwable
                ) {
                    Toast.makeText(
                        this@DashboardActivity,
                        "Error: ${t.message ?: "Koneksi gagal"}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            })
    }

    private fun searchMovies(keyword: String) {
        ApiClient.instance.searchMovie(keyword)
            .enqueue(object : Callback<MovieResponse> {

                override fun onResponse(
                    call: Call<MovieResponse>,
                    response: Response<MovieResponse>
                ) {
                    val result = response.body()

                    if (response.isSuccessful &&
                        result != null &&
                        result.success
                    ) {
                        movieList.clear()
                        movieList.addAll(result.data)
                        adapter.notifyDataSetChanged()
                    } else {
                        movieList.clear()
                        adapter.notifyDataSetChanged()
                    }
                }

                override fun onFailure(
                    call: Call<MovieResponse>,
                    t: Throwable
                ) {
                    Toast.makeText(
                        this@DashboardActivity,
                        "Error: ${t.message ?: "Pencarian gagal"}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }

    override fun onMovieClick(movie: Movie) {
        val intent = Intent(
            this,
            DetailMovieActivity::class.java
        )
        intent.putExtra("movie", movie)
        startActivity(intent)
    }
}
