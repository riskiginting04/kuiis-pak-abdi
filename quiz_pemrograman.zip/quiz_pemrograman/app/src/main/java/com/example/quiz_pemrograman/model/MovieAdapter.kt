package com.example.quiz_pemrograman.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.quiz_pemrograman.R
import com.example.quiz_pemrograman.model.Movie

class MovieAdapter(
    private val movieList: ArrayList<Movie>,
    private val listener: OnMovieClickListener
) : RecyclerView.Adapter<MovieAdapter.MovieViewHolder>() {

    interface OnMovieClickListener {
        fun onMovieClick(movie: Movie)
    }

    inner class MovieViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val cardMovie: CardView = itemView.findViewById(R.id.cardMovie)
        val imgPoster: ImageView = itemView.findViewById(R.id.imgPoster)
        val tvJudul: TextView = itemView.findViewById(R.id.tvJudul)
        val tvGenre: TextView = itemView.findViewById(R.id.tvGenre)
        val tvRating: TextView = itemView.findViewById(R.id.tvRating)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_movie, parent, false)

        return MovieViewHolder(view)

    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {

        val movie = movieList[position]

        holder.tvJudul.text = movie.judul
        holder.tvGenre.text = movie.genre
        holder.tvRating.text = "⭐ ${movie.rating}"

        if (movie.poster.isNotEmpty()) {

            Glide.with(holder.itemView.context)
                .load(movie.poster)
                .placeholder(R.mipmap.ic_launcher)
                .error(R.mipmap.ic_launcher)
                .into(holder.imgPoster)

        } else {

            holder.imgPoster.setImageResource(R.mipmap.ic_launcher)

        }

        holder.cardMovie.setOnClickListener {

            listener.onMovieClick(movie)

        }

    }

    override fun getItemCount(): Int {

        return movieList.size

    }

}