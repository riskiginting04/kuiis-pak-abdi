package com.example.quiz_pemrograman.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.quiz_pemrograman.R
import com.example.quiz_pemrograman.session.SessionManager

class ProfileActivity : AppCompatActivity() {

    private lateinit var tvNama: TextView
    private lateinit var tvEmail: TextView
    private lateinit var tvNoHp: TextView

    private lateinit var btnEditProfile: Button
    private lateinit var btnLogout: Button

    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportActionBar?.hide()
        setContentView(R.layout.activity_profile)

        session = SessionManager(this)

        tvNama = findViewById(R.id.tvNama)
        tvEmail = findViewById(R.id.tvEmail)
        tvNoHp = findViewById(R.id.tvNoHp)

        btnEditProfile = findViewById(R.id.btnEditProfile)
        btnLogout = findViewById(R.id.btnLogout)

        val sharedPreferences = getSharedPreferences(
            "CineVerseSession",
            MODE_PRIVATE
        )

        val nama = sharedPreferences.getString("nama", "")
        val email = sharedPreferences.getString("email", "")

        tvNama.text = nama ?: ""
        tvEmail.text = email ?: ""
        tvNoHp.text = "Nomor HP belum tersedia"

        btnEditProfile.setOnClickListener {
            Toast.makeText(
                this,
                "Fitur Edit Profile akan dibuat pada langkah berikutnya",
                Toast.LENGTH_SHORT
            ).show()
        }

        btnLogout.setOnClickListener {
            session.logout()

            val intent = Intent(this, LoginActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TASK
            }

            startActivity(intent)
            finish()
        }
    }
}
