package com.example.quiz_pemrograman.model

import com.google.gson.annotations.SerializedName

data class MovieResponse(

    @SerializedName("success")
    val success: Boolean,

    @SerializedName("message")
    val message: String,

    @SerializedName("data")
    val data: ArrayList<Movie>

)