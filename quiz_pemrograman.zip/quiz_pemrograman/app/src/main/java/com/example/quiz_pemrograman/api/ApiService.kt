package com.example.quiz_pemrograman.api

import com.example.quiz_pemrograman.model.LoginResponse
import com.example.quiz_pemrograman.model.MovieResponse
import com.example.quiz_pemrograman.model.ProfileResponse
import com.example.quiz_pemrograman.model.RegisterResponse
import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface ApiService {

    // ==========================
    // LOGIN
    // ==========================

    @FormUrlEncoded
    @POST("login.php")
    fun login(

        @Field("email")
        email: String,

        @Field("password")
        password: String

    ): Call<LoginResponse>

    // ==========================
    // REGISTER
    // ==========================

    @FormUrlEncoded
    @POST("register.php")
    fun register(

        @Field("nama")
        nama: String,

        @Field("email")
        email: String,

        @Field("password")
        password: String

    ): Call<RegisterResponse>

    // ==========================
    // GET MOVIES
    // ==========================

    @GET("get_movies.php")
    fun getMovies(): Call<MovieResponse>

    // ==========================
    // SEARCH MOVIE
    // ==========================

    @GET("search_movie.php")
    fun searchMovie(

        @Query("keyword")
        keyword: String

    ): Call<MovieResponse>

    // ==========================
    // GET PROFILE
    // ==========================

    @GET("get_profile.php")
    fun getProfile(

        @Query("id")
        id: String

    ): Call<ProfileResponse>

}