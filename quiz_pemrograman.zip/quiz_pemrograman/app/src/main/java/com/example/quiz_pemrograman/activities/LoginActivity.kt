package com.example.quiz_pemrograman.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.quiz_pemrograman.R
import com.example.quiz_pemrograman.api.ApiClient
import com.example.quiz_pemrograman.model.LoginResponse
import com.example.quiz_pemrograman.session.SessionManager
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {

    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText

    private lateinit var btnLogin: Button
    private lateinit var tvRegister: TextView
    private lateinit var progressBar: ProgressBar

    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportActionBar?.hide()
        setContentView(R.layout.activity_login)

        session = SessionManager(this)

        if (session.isLogin()) {
            startActivity(Intent(this, DashboardActivity::class.java))
            finish()
            return
        }

        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)

        btnLogin = findViewById(R.id.btnLogin)
        tvRegister = findViewById(R.id.tvRegister)
        progressBar = findViewById(R.id.progressBar)

        btnLogin.setOnClickListener {
            login()
        }

        tvRegister.setOnClickListener {
            startActivity(
                Intent(this, RegisterActivity::class.java)
            )
        }
    }

    private fun login() {
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString().trim()

        if (email.isEmpty()) {
            etEmail.error = "Email tidak boleh kosong"
            etEmail.requestFocus()
            return
        }

        if (password.isEmpty()) {
            etPassword.error = "Password tidak boleh kosong"
            etPassword.requestFocus()
            return
        }

        progressBar.visibility = View.VISIBLE
        btnLogin.isEnabled = false

        ApiClient.instance.login(email, password)
            .enqueue(object : Callback<LoginResponse> {

                override fun onResponse(
                    call: Call<LoginResponse>,
                    response: Response<LoginResponse>
                ) {
                    progressBar.visibility = View.GONE
                    btnLogin.isEnabled = true

                    val loginResponse = response.body()

                    if (response.isSuccessful &&
                        loginResponse != null &&
                        loginResponse.success
                    ) {
                        val user = loginResponse.user

                        if (user == null) {
                            Toast.makeText(
                                this@LoginActivity,
                                "Data pengguna tidak ditemukan",
                                Toast.LENGTH_SHORT
                            ).show()
                            return
                        }

                        session.saveLogin(
                            user.id.toString(),
                            user.nama,
                            user.email
                        )

                        Toast.makeText(
                            this@LoginActivity,
                            "Login berhasil",
                            Toast.LENGTH_SHORT
                        ).show()

                        startActivity(
                            Intent(
                                this@LoginActivity,
                                DashboardActivity::class.java
                            )
                        )

                        finish()
                    } else {
                        Toast.makeText(
                            this@LoginActivity,
                            loginResponse?.message ?: "Login gagal",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onFailure(
                    call: Call<LoginResponse>,
                    t: Throwable
                ) {
                    progressBar.visibility = View.GONE
                    btnLogin.isEnabled = true

                    Toast.makeText(
                        this@LoginActivity,
                        "Error: ${t.message ?: "Koneksi gagal"}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            })
    }
}