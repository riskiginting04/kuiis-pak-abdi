package com.example.quiz_pemrograman.session

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {

    private val PREF_NAME = "MovieAppSession"

    private val KEY_IS_LOGIN = "is_login"
    private val KEY_ID = "id"
    private val KEY_NAMA = "nama"
    private val KEY_EMAIL = "email"

    private val pref: SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    private val editor: SharedPreferences.Editor =
        pref.edit()

    fun saveLogin(
        id: String,
        nama: String,
        email: String
    ) {

        editor.putBoolean(KEY_IS_LOGIN, true)
        editor.putString(KEY_ID, id)
        editor.putString(KEY_NAMA, nama)
        editor.putString(KEY_EMAIL, email)
        editor.apply()

    }

    fun isLogin(): Boolean {

        return pref.getBoolean(KEY_IS_LOGIN, false)

    }

    fun getId(): String {

        return pref.getString(KEY_ID, "") ?: ""

    }

    fun getNama(): String {

        return pref.getString(KEY_NAMA, "") ?: ""

    }

    fun getEmail(): String {

        return pref.getString(KEY_EMAIL, "") ?: ""

    }

    fun logout() {

        editor.clear()
        editor.apply()

    }

}