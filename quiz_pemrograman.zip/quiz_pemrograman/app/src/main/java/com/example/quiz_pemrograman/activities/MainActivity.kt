package com.example.quiz_pemrograman.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.quiz_pemrograman.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}